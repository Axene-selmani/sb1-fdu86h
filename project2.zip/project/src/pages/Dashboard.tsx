import React from 'react';
import { useStore } from '../store';
import { BarChart3, TrendingUp, Package, AlertTriangle } from 'lucide-react';

export function Dashboard() {
  const { products, sales, purchases } = useStore();

  const totalSales = sales.reduce((acc, sale) => acc + sale.total, 0);
  const totalPurchases = purchases.reduce((acc, purchase) => acc + purchase.total, 0);
  const lowStockProducts = products.filter(
    (product) => product.currentStock <= product.reorderPoint
  );

  const stats = [
    {
      name: 'Total Sales',
      value: `$${totalSales.toLocaleString()}`,
      icon: BarChart3,
      change: '+4.75%',
      changeType: 'positive',
    },
    {
      name: 'Total Purchases',
      value: `$${totalPurchases.toLocaleString()}`,
      icon: TrendingUp,
      change: '+54.02%',
      changeType: 'positive',
    },
    {
      name: 'Products in Stock',
      value: products.length,
      icon: Package,
      change: '-1.39%',
      changeType: 'negative',
    },
    {
      name: 'Low Stock Alerts',
      value: lowStockProducts.length,
      icon: AlertTriangle,
      change: '+10.18%',
      changeType: 'negative',
    },
  ];

  return (
    <div className="space-y-6">
      <div className="sm:flex sm:items-center sm:justify-between">
        <h1 className="text-2xl font-semibold text-gray-900">Dashboard</h1>
      </div>

      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div
              key={stat.name}
              className="relative overflow-hidden rounded-lg bg-white px-4 pt-5 pb-12 shadow sm:px-6 sm:pt-6"
            >
              <dt>
                <div className="absolute rounded-md bg-indigo-500 p-3">
                  <Icon className="h-6 w-6 text-white" aria-hidden="true" />
                </div>
                <p className="ml-16 truncate text-sm font-medium text-gray-500">
                  {stat.name}
                </p>
              </dt>
              <dd className="ml-16 flex items-baseline pb-6 sm:pb-7">
                <p className="text-2xl font-semibold text-gray-900">{stat.value}</p>
                <p
                  className={`ml-2 flex items-baseline text-sm font-semibold ${
                    stat.changeType === 'positive' ? 'text-green-600' : 'text-red-600'
                  }`}
                >
                  {stat.change}
                </p>
              </dd>
            </div>
          );
        })}
      </div>

      {/* Low Stock Alerts */}
      {lowStockProducts.length > 0 && (
        <div className="mt-8">
          <h2 className="text-lg font-medium text-gray-900">Low Stock Alerts</h2>
          <div className="mt-4 overflow-hidden rounded-lg bg-white shadow">
            <ul role="list" className="divide-y divide-gray-200">
              {lowStockProducts.map((product) => (
                <li key={product.id} className="px-6 py-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-gray-900">{product.name}</p>
                      <p className="text-sm text-gray-500">
                        Current Stock: {product.currentStock} {product.unit}s
                      </p>
                    </div>
                    <div className="flex items-center">
                      <span className="inline-flex items-center rounded-full bg-red-100 px-3 py-0.5 text-sm font-medium text-red-800">
                        Low Stock
                      </span>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
}