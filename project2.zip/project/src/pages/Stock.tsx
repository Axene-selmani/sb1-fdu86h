import React, { useState } from 'react';
import { useStore } from '../store';
import { Button } from '../components/Button';
import { Input } from '../components/Input';
import { Select } from '../components/Select';
import { Plus, AlertTriangle } from 'lucide-react';

export function Stock() {
  const { products, addProduct, addStockAdjustment } = useStore();
  const [showForm, setShowForm] = useState(false);
  const [showAdjustmentForm, setShowAdjustmentForm] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<string>('');

  const [productForm, setProductForm] = useState({
    name: '',
    description: '',
    currentStock: '',
    reorderPoint: '',
    unit: 'unit',
    unitPrice: '',
  });

  const [adjustmentForm, setAdjustmentForm] = useState({
    productId: '',
    quantity: '',
    reason: '',
    type: 'increase',
  });

  const handleProductSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newProduct = {
      id: crypto.randomUUID(),
      name: productForm.name,
      description: productForm.description,
      currentStock: Number(productForm.currentStock),
      reorderPoint: Number(productForm.reorderPoint),
      unit: productForm.unit as 'kg' | 'unit',
      unitPrice: Number(productForm.unitPrice),
    };

    addProduct(newProduct);
    setShowForm(false);
    setProductForm({
      name: '',
      description: '',
      currentStock: '',
      reorderPoint: '',
      unit: 'unit',
      unitPrice: '',
    });
  };

  const handleAdjustmentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const adjustment = {
      id: crypto.randomUUID(),
      date: new Date(),
      productId: adjustmentForm.productId,
      quantity: Number(adjustmentForm.quantity),
      reason: adjustmentForm.reason,
      type: adjustmentForm.type as 'increase' | 'decrease',
    };

    addStockAdjustment(adjustment);
    setShowAdjustmentForm(false);
    setAdjustmentForm({
      productId: '',
      quantity: '',
      reason: '',
      type: 'increase',
    });
  };

  return (
    <div className="space-y-6">
      <div className="sm:flex sm:items-center sm:justify-between">
        <h1 className="text-2xl font-semibold text-gray-900">Stock</h1>
        <div className="mt-4 sm:mt-0 space-x-3">
          <Button onClick={() => setShowAdjustmentForm(true)}>
            Ajustement Stock
          </Button>
          <Button onClick={() => setShowForm(true)} icon={Plus}>
            Nouveau Produit
          </Button>
        </div>
      </div>

      {showForm && (
        <div className="mt-6 bg-white shadow sm:rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <h3 className="text-lg font-medium leading-6 text-gray-900">
              Nouveau Produit
            </h3>
            <form onSubmit={handleProductSubmit} className="mt-5 space-y-4">
              <Input
                label="Nom"
                value={productForm.name}
                onChange={e => setProductForm(prev => ({ ...prev, name: e.target.value }))}
                required
              />
              <Input
                label="Description"
                value={productForm.description}
                onChange={e => setProductForm(prev => ({ ...prev, description: e.target.value }))}
              />
              <Input
                label="Stock Initial"
                type="number"
                min="0"
                value={productForm.currentStock}
                onChange={e => setProductForm(prev => ({ ...prev, currentStock: e.target.value }))}
                required
              />
              <Input
                label="Seuil de Réapprovisionnement"
                type="number"
                min="0"
                value={productForm.reorderPoint}
                onChange={e => setProductForm(prev => ({ ...prev, reorderPoint: e.target.value }))}
                required
              />
              <Select
                label="Unité"
                options={[
                  { value: 'unit', label: 'Unité' },
                  { value: 'kg', label: 'Kilogramme' },
                ]}
                value={productForm.unit}
                onChange={e => setProductForm(prev => ({ ...prev, unit: e.target.value }))}
                required
              />
              <Input
                label="Prix Unitaire"
                type="number"
                min="0"
                step="0.01"
                value={productForm.unitPrice}
                onChange={e => setProductForm(prev => ({ ...prev, unitPrice: e.target.value }))}
                required
              />
              <div className="flex justify-end space-x-3">
                <Button
                  variant="secondary"
                  onClick={() => setShowForm(false)}
                  type="button"
                >
                  Annuler
                </Button>
                <Button type="submit">
                  Enregistrer
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {showAdjustmentForm && (
        <div className="mt-6 bg-white shadow sm:rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <h3 className="text-lg font-medium leading-6 text-gray-900">
              Ajustement de Stock
            </h3>
            <form onSubmit={handleAdjustmentSubmit} className="mt-5 space-y-4">
              <Select
                label="Produit"
                options={products.map(p => ({ 
                  value: p.id, 
                  label: `${p.name} (Stock: ${p.currentStock} ${p.unit}s)` 
                }))}
                value={adjustmentForm.productId}
                onChange={e => setAdjustmentForm(prev => ({ ...prev, productId: e.target.value }))}
                required
              />
              <Select
                label="Type d'ajustement"
                options={[
                  { value: 'increase', label: 'Augmentation' },
                  { value: 'decrease', label: 'Diminution' },
                ]}
                value={adjustmentForm.type}
                onChange={e => setAdjustmentForm(prev => ({ ...prev, type: e.target.value }))}
                required
              />
              <Input
                label="Quantité"
                type="number"
                min="0"
                value={adjustmentForm.quantity}
                onChange={e => setAdjustmentForm(prev => ({ ...prev, quantity: e.target.value }))}
                required
              />
              <Input
                label="Raison"
                value={adjustmentForm.reason}
                onChange={e => setAdjustmentForm(prev => ({ ...prev, reason: e.target.value }))}
                required
              />
              <div className="flex justify-end space-x-3">
                <Button
                  variant="secondary"
                  onClick={() => setShowAdjustmentForm(false)}
                  type="button"
                >
                  Annuler
                </Button>
                <Button type="submit">
                  Enregistrer
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="mt-8 bg-white shadow overflow-hidden sm:rounded-lg">
        <div className="px-4 py-5 sm:p-6">
          <div className="flex flex-col">
            <div className="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
              <div className="py-2 align-middle inline-block min-w-full sm:px-6 lg:px-8">
                <div className="shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Produit
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Stock Actuel
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Seuil
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Prix Unitaire
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Statut
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {products.map((product) => (
                        <tr key={product.id}>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm font-medium text-gray-900">{product.name}</div>
                            <div className="text-sm text-gray-500">{product.description}</div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {product.currentStock} {product.unit}s
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {product.reorderPoint} {product.unit}s
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {product.unitPrice.toLocaleString()} €
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            {product.currentStock <= product.reorderPoint ? (
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                                <AlertTriangle className="w-4 h-4 mr-1" />
                                Stock Bas
                              </span>
                            ) : (
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                En Stock
                              </span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}