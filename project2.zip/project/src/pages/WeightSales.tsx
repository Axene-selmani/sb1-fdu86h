import React, { useState } from 'react';
import { useStore } from '../store';
import { Button } from '../components/Button';
import { Input } from '../components/Input';
import { Select } from '../components/Select';
import { Plus, Scale } from 'lucide-react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';

export function WeightSales() {
  const { products, customers, sales, addSale } = useStore();
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    customerId: '',
    productId: '',
    weight: '',
    pricePerKg: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const product = products.find(p => p.id === formData.productId);
    if (!product || product.unit !== 'kg') return;

    const weight = Number(formData.weight);
    const pricePerKg = Number(formData.pricePerKg);

    if (weight > product.currentStock) {
      alert('Stock insuffisant');
      return;
    }

    const sale = {
      id: crypto.randomUUID(),
      date: new Date(),
      customerId: formData.customerId,
      productId: formData.productId,
      quantity: weight,
      unitPrice: pricePerKg,
      total: weight * pricePerKg,
      isWeightBased: true,
    };

    addSale(sale);
    setShowForm(false);
    setFormData({
      customerId: '',
      productId: '',
      weight: '',
      pricePerKg: '',
    });
  };

  const weightBasedSales = sales.filter(sale => sale.isWeightBased);
  const weightBasedProducts = products.filter(product => product.unit === 'kg');

  return (
    <div className="space-y-6">
      <div className="sm:flex sm:items-center sm:justify-between">
        <h1 className="text-2xl font-semibold text-gray-900">Ventes au Poids</h1>
        <div className="mt-4 sm:mt-0">
          <Button onClick={() => setShowForm(true)} icon={Scale}>
            Nouvelle Vente au Poids
          </Button>
        </div>
      </div>

      {showForm && (
        <div className="mt-6 bg-white shadow sm:rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <h3 className="text-lg font-medium leading-6 text-gray-900">
              Nouvelle Vente au Poids
            </h3>
            <form onSubmit={handleSubmit} className="mt-5 space-y-4">
              <Select
                label="Client"
                options={customers.map(c => ({ value: c.id, label: c.name }))}
                value={formData.customerId}
                onChange={e => setFormData(prev => ({ ...prev, customerId: e.target.value }))}
                required
              />
              <Select
                label="Produit"
                options={weightBasedProducts.map(p => ({ 
                  value: p.id, 
                  label: `${p.name} (Stock: ${p.currentStock} kg)` 
                }))}
                value={formData.productId}
                onChange={e => {
                  const product = products.find(p => p.id === e.target.value);
                  setFormData(prev => ({ 
                    ...prev, 
                    productId: e.target.value,
                    pricePerKg: product ? String(product.unitPrice) : ''
                  }));
                }}
                required
              />
              <Input
                label="Poids (kg)"
                type="number"
                min="0.001"
                step="0.001"
                value={formData.weight}
                onChange={e => setFormData(prev => ({ ...prev, weight: e.target.value }))}
                required
              />
              <Input
                label="Prix par kg"
                type="number"
                min="0"
                step="0.01"
                value={formData.pricePerKg}
                onChange={e => setFormData(prev => ({ ...prev, pricePerKg: e.target.value }))}
                required
              />
              <div className="flex justify-end space-x-3">
                <Button
                  variant="secondary"
                  onClick={() => setShowForm(false)}
                  type="button"
                >
                  Annuler
                </Button>
                <Button type="submit">
                  Enregistrer
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="mt-8 bg-white shadow overflow-hidden sm:rounded-lg">
        <div className="px-4 py-5 sm:p-6">
          <h3 className="text-lg font-medium leading-6 text-gray-900">
            Historique des Ventes au Poids
          </h3>
          <div className="mt-4 flex flex-col">
            <div className="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
              <div className="py-2 align-middle inline-block min-w-full sm:px-6 lg:px-8">
                <div className="shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Date
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Client
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Produit
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Poids
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Prix/kg
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Total
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {weightBasedSales.map((sale) => {
                        const customer = customers.find(c => c.id === sale.customerId);
                        const product = products.find(p => p.id === sale.productId);
                        return (
                          <tr key={sale.id}>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {format(sale.date, 'Pp', { locale: fr })}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {customer?.name}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {product?.name}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {sale.quantity.toFixed(3)} kg
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {sale.unitPrice.toLocaleString()} €/kg
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {sale.total.toLocaleString()} €
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}