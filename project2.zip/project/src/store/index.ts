import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { Product, Supplier, Customer, Purchase, Sale, StockAdjustment } from '../types';

interface StoreState {
  products: Product[];
  suppliers: Supplier[];
  customers: Customer[];
  purchases: Purchase[];
  sales: Sale[];
  stockAdjustments: StockAdjustment[];
  
  addProduct: (product: Product) => void;
  updateProduct: (product: Product) => void;
  addSupplier: (supplier: Supplier) => void;
  addCustomer: (customer: Customer) => void;
  addPurchase: (purchase: Purchase) => void;
  addSale: (sale: Sale) => void;
  addStockAdjustment: (adjustment: StockAdjustment) => void;
}

export const useStore = create<StoreState>()(
  persist(
    (set) => ({
      products: [],
      suppliers: [],
      customers: [],
      purchases: [],
      sales: [],
      stockAdjustments: [],

      addProduct: (product) =>
        set((state) => ({ products: [...state.products, product] })),

      updateProduct: (product) =>
        set((state) => ({
          products: state.products.map((p) =>
            p.id === product.id ? product : p
          ),
        })),

      addSupplier: (supplier) =>
        set((state) => ({ suppliers: [...state.suppliers, supplier] })),

      addCustomer: (customer) =>
        set((state) => ({ customers: [...state.customers, customer] })),

      addPurchase: (purchase) =>
        set((state) => {
          const updatedProducts = state.products.map((product) => {
            if (product.id === purchase.productId) {
              return {
                ...product,
                currentStock: product.currentStock + purchase.quantity,
              };
            }
            return product;
          });

          return {
            purchases: [...state.purchases, purchase],
            products: updatedProducts,
          };
        }),

      addSale: (sale) =>
        set((state) => {
          const updatedProducts = state.products.map((product) => {
            if (product.id === sale.productId) {
              return {
                ...product,
                currentStock: product.currentStock - sale.quantity,
              };
            }
            return product;
          });

          return {
            sales: [...state.sales, sale],
            products: updatedProducts,
          };
        }),

      addStockAdjustment: (adjustment) =>
        set((state) => {
          const updatedProducts = state.products.map((product) => {
            if (product.id === adjustment.productId) {
              const adjustmentQuantity =
                adjustment.type === 'increase'
                  ? adjustment.quantity
                  : -adjustment.quantity;
              return {
                ...product,
                currentStock: product.currentStock + adjustmentQuantity,
              };
            }
            return product;
          });

          return {
            stockAdjustments: [...state.stockAdjustments, adjustment],
            products: updatedProducts,
          };
        }),
    }),
    {
      name: 'inventory-storage',
    }
  )
);