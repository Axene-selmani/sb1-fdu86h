export interface Product {
  id: string;
  name: string;
  description: string;
  currentStock: number;
  reorderPoint: number;
  unit: 'kg' | 'unit';
  unitPrice: number;
}

export interface Supplier {
  id: string;
  name: string;
  contact: string;
  email: string;
  phone: string;
}

export interface Customer {
  id: string;
  name: string;
  contact: string;
  email: string;
  phone: string;
}

export interface Purchase {
  id: string;
  date: Date;
  supplierId: string;
  productId: string;
  quantity: number;
  unitPrice: number;
  total: number;
}

export interface Sale {
  id: string;
  date: Date;
  customerId: string;
  productId: string;
  quantity: number;
  unitPrice: number;
  total: number;
  isWeightBased: boolean;
}

export interface StockAdjustment {
  id: string;
  date: Date;
  productId: string;
  quantity: number;
  reason: string;
  type: 'increase' | 'decrease';
}